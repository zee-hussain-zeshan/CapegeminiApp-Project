class EnrolmentcsvsController < ApplicationController

	def enrolments_upload
	end

	def import
		@f=params[:file]
	end

end
